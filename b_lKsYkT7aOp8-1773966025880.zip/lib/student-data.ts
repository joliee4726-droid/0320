// Mock student data structure (would come from Google Sheets in production)
export interface StudentRecord {
  id: string
  name: string
  studentId: string
  gender: string
  grade: string
  gpa: string
  major: string
  phone: string
  signal: "red" | "yellow" | "blue"
  status: "미배정" | "진행중" | "완료"
  assignedCounselor: string // counselor name or "미배정"
  createdDate: string
  sessionCount: number
}

// Mock initial student data
export const INITIAL_STUDENTS: StudentRecord[] = [
  {
    id: "1",
    name: "홍길동",
    studentId: "20240001",
    gender: "남",
    grade: "3",
    gpa: "3.8",
    major: "컴퓨터공학과",
    phone: "010-1234-5678",
    signal: "red",
    status: "미배정",
    assignedCounselor: "미배정",
    createdDate: "2024-03-10",
    sessionCount: 0,
  },
  {
    id: "2",
    name: "이순신",
    studentId: "20240002",
    gender: "남",
    grade: "2",
    gpa: "3.5",
    major: "경영학과",
    phone: "010-2345-6789",
    signal: "yellow",
    status: "미배정",
    assignedCounselor: "미배정",
    createdDate: "2024-03-11",
    sessionCount: 0,
  },
  {
    id: "3",
    name: "김영희",
    studentId: "20240003",
    gender: "여",
    grade: "4",
    gpa: "4.0",
    major: "전자공학과",
    phone: "010-3456-7890",
    signal: "blue",
    status: "미배정",
    assignedCounselor: "미배정",
    createdDate: "2024-03-09",
    sessionCount: 0,
  },
  {
    id: "4",
    name: "박민준",
    studentId: "20240004",
    gender: "남",
    grade: "1",
    gpa: "3.2",
    major: "화학과",
    phone: "010-4567-8901",
    signal: "red",
    status: "진행중",
    assignedCounselor: "김상담사",
    createdDate: "2024-03-08",
    sessionCount: 2,
  },
  {
    id: "5",
    name: "최지은",
    studentId: "20240005",
    gender: "여",
    grade: "3",
    gpa: "3.6",
    major: "생물학과",
    phone: "010-5678-9012",
    signal: "yellow",
    status: "진행중",
    assignedCounselor: "이상담사",
    createdDate: "2024-03-07",
    sessionCount: 1,
  },
]

// Filter students by counselor
export function filterStudentsByCounselor(
  students: StudentRecord[],
  counselorName: string,
  isMasterMode: boolean
): StudentRecord[] {
  if (isMasterMode) {
    // Master sees all students
    return students
  }

  // Regular counselor sees:
  // 1. Unassigned students (미배정)
  // 2. Students assigned to them
  return students.filter(
    (student) =>
      student.assignedCounselor === "미배정" ||
      student.assignedCounselor === counselorName
  )
}

// Assign student to counselor
export function assignStudentToCounselor(
  students: StudentRecord[],
  studentId: string,
  counselorName: string
): StudentRecord[] {
  return students.map((student) => {
    if (student.id === studentId && student.assignedCounselor === "미배정") {
      return {
        ...student,
        assignedCounselor: counselorName,
        status: "진행중",
        sessionCount: 1,
      }
    }
    return student
  })
}

// Update student status
export function updateStudentStatus(
  students: StudentRecord[],
  studentId: string,
  status: "미배정" | "진행중" | "완료",
  sessionCount?: number
): StudentRecord[] {
  return students.map((student) => {
    if (student.id === studentId) {
      return {
        ...student,
        status,
        sessionCount: sessionCount ?? student.sessionCount,
      }
    }
    return student
  })
}
