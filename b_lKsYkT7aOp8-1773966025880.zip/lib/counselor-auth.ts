// List of 8 counselors in the system
export const COUNSELORS = [
  "김상담사",
  "이상담사",
  "박상담사",
  "최상담사",
  "정상담사",
  "한상담사",
  "오상담사",
  "강상담사",
]

// Passwords
export const COUNSELOR_PASSWORD = "unicare2024"
export const ADMIN_PASSWORD = "unicare2026"
export const MASTER_PASSWORD = "unicare-master"

export interface CounselorSession {
  counselorName: string
  isMasterMode: boolean
  loginTime: string
}

// Validate counselor login
export function validateCounselorLogin(
  name: string,
  password: string
): { valid: boolean; isMasterMode: boolean } {
  // Check if master password
  if (password === MASTER_PASSWORD) {
    return { valid: true, isMasterMode: true }
  }

  // Check if admin password (for new login system)
  if (password === ADMIN_PASSWORD) {
    return { valid: true, isMasterMode: false }
  }

  // Check if counselor exists and password matches
  if (COUNSELORS.includes(name) && password === COUNSELOR_PASSWORD) {
    return { valid: true, isMasterMode: false }
  }

  return { valid: false, isMasterMode: false }
}
