"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export interface ProfileData {
  // 신규/기존 상태
  userStatus: "new" | "existing" | ""
  // 대상자 유형
  targetType: "재학생" | "졸업생" | "지역청년" | ""
  // 공통 필드
  name: string
  gender: string
  phone: string
  referralPath: string
  // 재학생/졸업생 필드
  studentId: string
  major: string
  doubleMajor: string
  minor: string
  grade: string
  gpa: string
  academicStatus: string
  graduationDate: string
  // 지역청년 필드
  educationLevel: string
  residenceRegion: string
}

interface StepProfileProps {
  data: ProfileData
  onChange: (data: ProfileData) => void
  isExistingUser?: boolean
}

export function StepProfile({ data, onChange, isExistingUser = false }: StepProfileProps) {
  const set = (patch: Partial<ProfileData>) => onChange({ ...data, ...patch })

  return (
    <div className="space-y-8">
      {/* ── Step 1: 대상자 유형 선택 (신규만 표시) ── */}
      {data.userStatus === "new" && (
        <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-300">
          <div>
            <h3 className="text-lg font-bold text-[var(--unicare-navy)] mb-4">1단계: 대상자 유형 선택</h3>
            <p className="text-sm text-gray-600 mb-4">해당하는 대상자 유형을 선택해주세요</p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {["재학생", "졸업생", "지역청년"].map((type) => (
              <button
                key={type}
                onClick={() => set({ targetType: type as "재학생" | "졸업생" | "지역청년" })}
                className={cn(
                  "p-5 rounded-2xl border-3 font-bold text-lg transition-all duration-200",
                  data.targetType === type
                    ? "border-[var(--unicare-orange)] bg-orange-50 text-[var(--unicare-orange)] shadow-md"
                    : "border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50"
                )}
              >
                {type}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── 기본 정보 입력 ── */}
      <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
        <div>
          <h3 className="text-lg font-bold text-[var(--unicare-navy)] mb-4">
            {data.userStatus === "new" ? "2단계: 기본 정보 입력" : "기본 정보 입력"}
          </h3>
        </div>

          {/* 성명, 성별 */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="font-semibold text-[var(--unicare-navy)]">성명 *</Label>
              <Input
                value={data.name}
                onChange={(e) => set({ name: e.target.value })}
                placeholder="홍길동"
                className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-semibold text-[var(--unicare-navy)]">성별 *</Label>
              <div className="flex gap-4">
                {["남", "여"].map((g) => (
                  <button
                    key={g}
                    onClick={() => set({ gender: g })}
                    className={cn(
                      "flex-1 py-3 rounded-xl border-2 font-medium transition-all",
                      data.gender === g
                        ? "border-[var(--unicare-orange)] bg-orange-50 text-[var(--unicare-orange)]"
                        : "border-gray-200 text-gray-400 hover:border-gray-300"
                    )}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 연락처, 유입경로 */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="font-semibold text-[var(--unicare-navy)]">연락처 *</Label>
              <Input
                value={data.phone}
                onChange={(e) => set({ phone: e.target.value })}
                placeholder="010-0000-0000"
                className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-semibold text-[var(--unicare-navy)]">유입 경로 *</Label>
              <Select value={data.referralPath} onValueChange={(v) => set({ referralPath: v })}>
                <SelectTrigger className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]">
                  <SelectValue placeholder="선택" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="학과공지">학과 공지사항</SelectItem>
                  <SelectItem value="SNS">공식 SNS (인스타 등)</SelectItem>
                  <SelectItem value="에브리타임">에브리타임</SelectItem>
                  <SelectItem value="지인추천">지인 / 친구 추천</SelectItem>
                  <SelectItem value="현수막">교내 현수막 / 포스터</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* ── 재학생 / 졸업생 필드 (신규만 표시) ── */}
          {data.userStatus === "new" && (data.targetType === "재학생" || data.targetType === "졸업생") && (
            <div className="space-y-6 p-6 bg-blue-50 rounded-2xl border-2 border-blue-200 animate-in fade-in duration-300">
              <h4 className="font-bold text-[var(--unicare-navy)]">
                {data.targetType === "재학생" ? "재학생 정보" : "졸업생 정보"}
              </h4>

              {/* 학번, 주전공 */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="font-semibold text-[var(--unicare-navy)]">학번 *</Label>
                  <Input
                    value={data.studentId}
                    onChange={(e) => set({ studentId: e.target.value })}
                    placeholder="20240001"
                    className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="font-semibold text-[var(--unicare-navy)]">주전공 *</Label>
                  <Input
                    value={data.major}
                    onChange={(e) => set({ major: e.target.value })}
                    placeholder="컴퓨터공학과"
                    className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
                  />
                </div>
              </div>

              {/* 복수전공, 부전공 */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="font-semibold text-[var(--unicare-navy)]">복수전공</Label>
                  <Input
                    value={data.doubleMajor}
                    onChange={(e) => set({ doubleMajor: e.target.value })}
                    placeholder="해당 시 입력"
                    className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-semibold text-[var(--unicare-navy)]">부전공</Label>
                  <Input
                    value={data.minor}
                    onChange={(e) => set({ minor: e.target.value })}
                    placeholder="해당 시 입력"
                    className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
                  />
                </div>
              </div>

              {/* 학년, 평점 */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="font-semibold text-[var(--unicare-navy)]">학년 *</Label>
                  <Select value={data.grade} onValueChange={(v) => set({ grade: v })}>
                    <SelectTrigger className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]">
                      <SelectValue placeholder="선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4].map((g) => (
                        <SelectItem key={g} value={g.toString()}>
                          {g}학년
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="font-semibold text-[var(--unicare-navy)]">평점 (GPA)</Label>
                  <Input
                    type="number"
                    step="0.1"
                    min={0}
                    max={4.5}
                    value={data.gpa}
                    onChange={(e) => set({ gpa: e.target.value })}
                    placeholder="4.5"
                    className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
                  />
                </div>
              </div>

              {/* 학적상태 */}
              <div className="space-y-2">
                <Label className="font-semibold text-[var(--unicare-navy)]">학적 상태 *</Label>
                <Select value={data.academicStatus} onValueChange={(v) => set({ academicStatus: v })}>
                  <SelectTrigger className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]">
                    <SelectValue placeholder="상태 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="재학">재학</SelectItem>
                    <SelectItem value="휴학">휴학</SelectItem>
                    <SelectItem value="수료">수료</SelectItem>
                    <SelectItem value="졸업">졸업</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 졸업 년월 (조건부) */}
              {data.academicStatus === "졸업" && (
                <div className="p-4 bg-orange-50 rounded-xl border-2 border-orange-200 animate-in fade-in duration-300">
                  <Label className="font-semibold text-[var(--unicare-orange)]">졸업 년월 *</Label>
                  <Input
                    type="month"
                    value={data.graduationDate}
                    onChange={(e) => set({ graduationDate: e.target.value })}
                    className="mt-3 h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
                  />
                  <p className="text-xs text-[var(--unicare-orange)] mt-2">졸업생 취업 조사를 위해 정확한 시기를 입력해주세요.</p>
                </div>
              )}
            </div>
          )}

          {/* ── 지역청년 필드 (신규만 표시) ── */}
          {data.userStatus === "new" && data.targetType === "지역청년" && (
            <div className="space-y-6 p-6 bg-green-50 rounded-2xl border-2 border-green-200 animate-in fade-in duration-300">
              <h4 className="font-bold text-[var(--unicare-navy)]">지역청년 정보</h4>

              {/* 최종학력 */}
              <div className="space-y-2">
                <Label className="font-semibold text-[var(--unicare-navy)]">최종학력 *</Label>
                <Select value={data.educationLevel} onValueChange={(v) => set({ educationLevel: v })}>
                  <SelectTrigger className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]">
                    <SelectValue placeholder="선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="고졸">고등학교 졸업</SelectItem>
                    <SelectItem value="대졸">대학교 졸업</SelectItem>
                    <SelectItem value="석사">석사 이상</SelectItem>
                    <SelectItem value="기타">기타</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* 거주 지역 */}
              <div className="space-y-2">
                <Label className="font-semibold text-[var(--unicare-navy)]">거주 지역 *</Label>
                <Select value={data.residenceRegion} onValueChange={(v) => set({ residenceRegion: v })}>
                  <SelectTrigger className="h-11 rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]">
                    <SelectValue placeholder="선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="서울">서울</SelectItem>
                    <SelectItem value="인천">인천</SelectItem>
                    <SelectItem value="경기">경기</SelectItem>
                    <SelectItem value="강원">강원</SelectItem>
                    <SelectItem value="충청">충청</SelectItem>
                    <SelectItem value="전라">전라</SelectItem>
                    <SelectItem value="경상">경상</SelectItem>
                    <SelectItem value="제주">제주</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <p className="text-sm text-gray-600 p-3 bg-white rounded-xl border-2 border-gray-200">
                학번 항목은 표시되지 않습니다. 지역청년 특화 상담을 진행합니다.
              </p>
            </div>
          )}
      </div>
    </div>
  )
}
