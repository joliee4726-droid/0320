"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Compass, Target, Lightbulb, CircleHelp, CheckCircle2 } from "lucide-react"
import { cn } from "@/lib/utils"

type SignalType = "red" | "yellow" | "blue" | "other" | null

interface SignalData {
  signal: SignalType
  otherText: string
  specificConcerns: string
  pastActivities: string
}

interface StepSignalProps {
  data: SignalData
  onChange: (data: SignalData) => void
}

const SIGNAL_OPTIONS = [
  {
    value: "red" as const,
    emoji: "🔴",
    label: "진로 방향 미결정",
    description: "어떤 진로를 선택해야 할지 모르겠어요",
    icon: Compass,
    color: "border-[var(--signal-red)]",
    bgColor: "bg-red-50",
    textColor: "text-[var(--signal-red)]",
    hoverBg: "hover:bg-red-50",
  },
  {
    value: "yellow" as const,
    emoji: "🟡",
    label: "전략 부재",
    description: "목표는 있지만 어떻게 달성할지 모르겠어요",
    icon: Target,
    color: "border-[var(--signal-yellow)]",
    bgColor: "bg-yellow-50",
    textColor: "text-[var(--signal-yellow)]",
    hoverBg: "hover:bg-yellow-50",
  },
  {
    value: "blue" as const,
    emoji: "🔵",
    label: "취업 스킬 부족",
    description: "방향은 정했지만 필요한 역량이 부족해요",
    icon: Lightbulb,
    color: "border-[var(--signal-blue)]",
    bgColor: "bg-blue-50",
    textColor: "text-[var(--signal-blue)]",
    hoverBg: "hover:bg-blue-50",
  },
  {
    value: "other" as const,
    emoji: "⚪",
    label: "기타",
    description: "위 항목에 해당하지 않는 고민이 있어요",
    icon: CircleHelp,
    color: "border-gray-400",
    bgColor: "bg-gray-50",
    textColor: "text-gray-600",
    hoverBg: "hover:bg-gray-50",
  },
]

const inputCls =
  "rounded-xl border-2 bg-white focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)] placeholder:text-gray-300 text-sm"

export function StepSignal({ data, onChange }: StepSignalProps) {
  const set = (patch: Partial<SignalData>) => onChange({ ...data, ...patch })

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="border-b bg-gradient-to-r from-[var(--unicare-navy)] to-[var(--unicare-navy-light)] rounded-t-xl text-white">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/10 rounded-lg">
            <Target className="w-6 h-6" />
          </div>
          <div>
            <CardTitle className="text-xl">상담 목적 및 계획</CardTitle>
            <CardDescription className="text-white/80">
              현재 고민 유형을 선택하고 상세 내용을 작성해주세요
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-8 space-y-8">
        {/* Signal Selection */}
        <div className="space-y-4">
          <Label className="font-semibold text-[var(--unicare-navy)] text-base">
            상담 신호 선택 (Signal)
          </Label>
          <div className="grid gap-4 md:grid-cols-2">
            {SIGNAL_OPTIONS.map((option) => {
              const Icon = option.icon
              const isSelected = data.signal === option.value

              return (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => set({ signal: option.value })}
                  className={cn(
                    "relative p-5 rounded-xl border-2 text-left transition-all duration-200",
                    isSelected
                      ? [option.color, option.bgColor, "shadow-md scale-[1.02]"]
                      : ["border-gray-200", option.hoverBg, "hover:border-gray-300"]
                  )}
                >
                  {isSelected && (
                    <div className="absolute top-3 right-3">
                      <CheckCircle2 className={cn("w-5 h-5", option.textColor)} />
                    </div>
                  )}
                  <div className="flex items-start gap-4">
                    <div
                      className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
                        isSelected ? option.bgColor : "bg-gray-100"
                      )}
                    >
                      <Icon
                        className={cn(
                          "w-6 h-6",
                          isSelected ? option.textColor : "text-gray-400"
                        )}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p
                        className={cn(
                          "font-bold text-base mb-1",
                          isSelected ? option.textColor : "text-[var(--unicare-navy)]"
                        )}
                      >
                        {option.emoji} {option.label}
                      </p>
                      <p className="text-sm text-gray-500">{option.description}</p>
                    </div>
                  </div>
                </button>
              )
            })}
          </div>
        </div>

        {/* Other text input */}
        {data.signal === "other" && (
          <div className="space-y-2 p-4 rounded-xl bg-gray-50 border border-gray-200">
            <Label className="font-semibold text-[var(--unicare-navy)] text-sm">
              기타 고민 내용
            </Label>
            <Input
              value={data.otherText}
              onChange={(e) => set({ otherText: e.target.value })}
              placeholder="구체적인 고민 내용을 입력해주세요"
              className={inputCls}
            />
          </div>
        )}

        {/* Specific Concerns */}
        <div className="space-y-3">
          <Label className="font-semibold text-[var(--unicare-navy)] text-base flex items-center gap-2">
            <div className="p-1.5 bg-[var(--unicare-orange)]/10 rounded-lg">
              <Compass className="w-4 h-4 text-[var(--unicare-orange)]" />
            </div>
            구체적인 고민 사항
          </Label>
          <Textarea
            value={data.specificConcerns}
            onChange={(e) => set({ specificConcerns: e.target.value })}
            placeholder="현재 겪고 있는 구체적인 고민이나 어려움을 자유롭게 작성해주세요..."
            className={cn(inputCls, "min-h-[120px] p-4 resize-none")}
          />
        </div>

        {/* Past Activities */}
        <div className="space-y-3">
          <Label className="font-semibold text-[var(--unicare-navy)] text-base flex items-center gap-2">
            <div className="p-1.5 bg-[var(--unicare-navy)]/10 rounded-lg">
              <Target className="w-4 h-4 text-[var(--unicare-navy)]" />
            </div>
            지금까지의 활동 및 노력
          </Label>
          <Textarea
            value={data.pastActivities}
            onChange={(e) => set({ pastActivities: e.target.value })}
            placeholder="진로 탐색을 위해 지금까지 해온 활동이나 노력을 작성해주세요 (예: 인턴십, 자격증, 프로젝트 등)..."
            className={cn(inputCls, "min-h-[120px] p-4 resize-none")}
          />
        </div>

        {/* Selected Signal Summary */}
        {data.signal && (
          <div
            className={cn(
              "p-4 rounded-xl border-2",
              SIGNAL_OPTIONS.find((o) => o.value === data.signal)?.bgColor,
              SIGNAL_OPTIONS.find((o) => o.value === data.signal)?.color
            )}
          >
            <p className="text-sm font-medium text-[var(--unicare-navy)]">
              선택된 상담 유형:{" "}
              <span
                className={cn(
                  "font-bold",
                  SIGNAL_OPTIONS.find((o) => o.value === data.signal)?.textColor
                )}
              >
                {SIGNAL_OPTIONS.find((o) => o.value === data.signal)?.emoji}{" "}
                {SIGNAL_OPTIONS.find((o) => o.value === data.signal)?.label}
              </span>
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
