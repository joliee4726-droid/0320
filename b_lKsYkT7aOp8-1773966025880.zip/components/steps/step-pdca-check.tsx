"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  ClipboardCheck,
  Star,
  ArrowRight,
  TrendingUp,
  MessageSquare,
  Compass,
  Target,
  Lightbulb,
  CircleHelp,
  ChevronDown,
} from "lucide-react"
import { cn } from "@/lib/utils"

type SignalType = "red" | "yellow" | "blue" | "other" | null

interface PDCACheckData {
  satisfactionRating: number
  beforeSignal: SignalType
  afterSignal: SignalType
  futureImprovements: string
}

interface StepPDCACheckProps {
  data: PDCACheckData
  onChange: (data: PDCACheckData) => void
  initialSignal: SignalType
}

// ──────────────────────────────────────────────
// Signal meta — single source of truth
// ──────────────────────────────────────────────
const SIGNAL_META: Record<
  string,
  {
    emoji: string
    label: string
    icon: React.ElementType
    dotColor: string
    borderColor: string
    bgColor: string
    textColor: string
  }
> = {
  red: {
    emoji: "🔴",
    label: "진로 방향 미결정",
    icon: Compass,
    dotColor: "bg-[var(--signal-red)]",
    borderColor: "border-[var(--signal-red)]",
    bgColor: "bg-red-50",
    textColor: "text-[var(--signal-red)]",
  },
  yellow: {
    emoji: "🟡",
    label: "전략 부재",
    icon: Target,
    dotColor: "bg-[var(--signal-yellow)]",
    borderColor: "border-[var(--signal-yellow)]",
    bgColor: "bg-yellow-50",
    textColor: "text-[var(--signal-yellow)]",
  },
  blue: {
    emoji: "🔵",
    label: "취업 스킬 부족",
    icon: Lightbulb,
    dotColor: "bg-[var(--signal-blue)]",
    borderColor: "border-[var(--signal-blue)]",
    bgColor: "bg-blue-50",
    textColor: "text-[var(--signal-blue)]",
  },
  other: {
    emoji: "⚪",
    label: "기타",
    icon: CircleHelp,
    dotColor: "bg-gray-400",
    borderColor: "border-gray-400",
    bgColor: "bg-gray-50",
    textColor: "text-gray-600",
  },
}

function getSignalMeta(signal: SignalType) {
  if (!signal) return null
  return SIGNAL_META[signal] ?? null
}

// ──────────────────────────────────────────────
// BeforeSignalCard — read-only, shows initial signal
// ──────────────────────────────────────────────
function BeforeSignalCard({ signal }: { signal: SignalType }) {
  const meta = getSignalMeta(signal)
  const Icon = meta?.icon ?? CircleHelp

  return (
    <div className={cn(
      "flex-1 flex flex-col items-center justify-center gap-3 p-6 rounded-2xl border-2",
      meta ? [meta.bgColor, meta.borderColor] : "bg-gray-50 border-gray-200"
    )}>
      <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest">상담 전 상태</p>
      <div className={cn(
        "w-14 h-14 rounded-full flex items-center justify-center",
        meta ? meta.dotColor : "bg-gray-200"
      )}>
        <Icon className="w-7 h-7 text-white" />
      </div>
      <p className={cn("font-bold text-base text-center", meta ? meta.textColor : "text-gray-400")}>
        {meta ? `${meta.emoji} ${meta.label}` : "미선택"}
      </p>
      <p className="text-xs text-gray-400 text-center">Step 2에서 선택한 초기 Signal</p>
    </div>
  )
}

// ──────────────────────────────────────────────
// AfterSignalSelect — dropdown, matches example
// ──────────────────────────────────────────────
function AfterSignalSelect({
  value,
  onChange,
}: {
  value: SignalType
  onChange: (v: SignalType) => void
}) {
  const meta = getSignalMeta(value)

  return (
    <div className={cn(
      "flex-1 flex flex-col items-center justify-center gap-3 p-6 rounded-2xl border-2 transition-all duration-300",
      meta ? [meta.bgColor, meta.borderColor] : "bg-blue-50 border-blue-200"
    )}>
      <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest">상담 후 현재 상태</p>

      {/* Signal icon — updates when selected */}
      <div className={cn(
        "w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300",
        meta ? meta.dotColor : "bg-gray-200"
      )}>
        {meta ? (
          <meta.icon className="w-7 h-7 text-white" />
        ) : (
          <CircleHelp className="w-7 h-7 text-gray-400" />
        )}
      </div>

      {/* Native select styled to match */}
      <div className="relative w-full max-w-[220px]">
        <select
          value={value ?? ""}
          onChange={(e) => onChange((e.target.value as SignalType) || null)}
          className={cn(
            "w-full appearance-none text-center font-bold text-sm rounded-xl px-4 py-2.5 pr-8",
            "border-2 bg-white cursor-pointer transition-all",
            "focus:outline-none focus:ring-2 focus:ring-offset-1",
            meta
              ? [meta.borderColor, meta.textColor, "focus:ring-[var(--unicare-orange)]"]
              : "border-gray-300 text-gray-400 focus:ring-[var(--unicare-orange)]"
          )}
        >
          <option value="">상태를 선택하세요</option>
          <option value="red">여전히 방황 중</option>
          <option value="yellow">전략이 생겼어요</option>
          <option value="blue">스킬 개발에 집중할게요</option>
          <option value="other">기타</option>
        </select>
        {/* Custom caret */}
        <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
      </div>

      <p className="text-xs text-gray-400 text-center">상담 후 나의 변화된 상태</p>
    </div>
  )
}

// ──────────────────────────────────────────────
// Improvement status badge
// ──────────────────────────────────────────────
function ImprovementBadge({
  before,
  after,
}: {
  before: SignalType
  after: SignalType
}) {
  if (!before || !after) return null

  const order: SignalType[] = ["red", "yellow", "blue", "other"]
  const bi = order.indexOf(before)
  const ai = order.indexOf(after)

  let label: string
  let cls: string

  if (after === before) {
    label = "상태 유지 — 지속적인 관심이 필요합니다"
    cls = "bg-yellow-50 border-yellow-200 text-yellow-700"
  } else if (ai > bi && after !== "other") {
    label = "긍정적 변화 — 상담 효과가 확인되었습니다"
    cls = "bg-green-50 border-green-200 text-green-700"
  } else {
    label = "추가 관찰 필요 — 후속 상담을 권장합니다"
    cls = "bg-orange-50 border-orange-200 text-orange-700"
  }

  return (
    <div className={cn("px-5 py-3 rounded-xl border-2 text-center font-semibold text-sm", cls)}>
      {label}
    </div>
  )
}

// ──────────────────────────────────────────────
// Star rating row
// ──────────────────────────────────────────────
function StarRating({
  rating,
  onChange,
}: {
  rating: number
  onChange: (v: number) => void
}) {
  const labels = ["", "매우 불만족", "불만족", "보통", "만족", "매우 만족"]

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="flex items-center gap-3">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className={cn(
              "w-14 h-14 rounded-2xl border-2 flex items-center justify-center transition-all duration-200",
              "hover:scale-110 hover:shadow-md",
              rating >= star
                ? "bg-[var(--unicare-orange)] border-[var(--unicare-orange)] text-white shadow-sm"
                : "bg-white border-gray-200 text-gray-300 hover:border-[var(--unicare-orange)]/50"
            )}
          >
            <Star className={cn("w-7 h-7", rating >= star ? "fill-white" : "")} />
          </button>
        ))}
      </div>

      {/* Labels */}
      <div className="flex items-center justify-between w-full px-1 text-xs text-gray-400">
        <span>매우 불만족</span>
        <span>매우 만족</span>
      </div>

      {/* Selected label */}
      {rating > 0 && (
        <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-[var(--unicare-orange)]/10 text-[var(--unicare-orange)] font-semibold text-sm">
          <Star className="w-4 h-4 fill-current" />
          {rating} / 5 — {labels[rating]}
        </div>
      )}
    </div>
  )
}

// ──────────────────────────────────────────────
// Main component
// ──────────────────────────────────────────────
export function StepPDCACheck({ data, onChange, initialSignal }: StepPDCACheckProps) {
  return (
    <div className="space-y-6">
      {/* ── 1. Satisfaction survey ── */}
      <Card className="border-0 shadow-lg">
        <CardHeader className="border-b bg-gradient-to-r from-[var(--unicare-navy)] to-[var(--unicare-navy-light)] rounded-t-xl text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg">
              <Star className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-xl">만족도 조사 (Check)</CardTitle>
              <CardDescription className="text-white/80">
                오늘 상담 경험을 평가해 주세요
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <p className="text-lg font-bold text-[var(--unicare-navy)]">
              오늘 상담은 만족스러우셨나요?
            </p>
            <p className="text-sm text-gray-400 mt-1">
              별점을 선택해 주세요
            </p>
          </div>
          <StarRating
            rating={data.satisfactionRating}
            onChange={(v) => onChange({ ...data, satisfactionRating: v })}
          />
        </CardContent>
      </Card>

      {/* ── 2. Before / After signal comparison ── */}
      <Card className="border-0 shadow-lg">
        <CardHeader className="border-b bg-muted/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[var(--unicare-navy)]/10 rounded-lg">
              <TrendingUp className="w-5 h-5 text-[var(--unicare-navy)]" />
            </div>
            <div>
              <CardTitle className="text-lg text-[var(--unicare-navy)]">
                상담 전/후 상태 비교 (PDCA 성과 지표)
              </CardTitle>
              <CardDescription>
                상담 전과 후의 나의 상태 변화를 비교합니다
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-8 space-y-6">
          {/* Cards row */}
          <div className="flex flex-col md:flex-row items-stretch gap-4">
            <BeforeSignalCard signal={initialSignal} />

            {/* Arrow */}
            <div className="flex items-center justify-center md:flex-col gap-2 py-2">
              <div className="p-3 rounded-full bg-[var(--unicare-navy)]/10">
                <ArrowRight className="w-5 h-5 text-[var(--unicare-navy)] md:block hidden" />
                {/* vertical arrow on mobile */}
                <ArrowRight className="w-5 h-5 text-[var(--unicare-navy)] md:hidden rotate-90" />
              </div>
            </div>

            <AfterSignalSelect
              value={data.afterSignal}
              onChange={(v) => onChange({ ...data, afterSignal: v })}
            />
          </div>

          {/* Improvement badge */}
          <ImprovementBadge before={initialSignal} after={data.afterSignal} />
        </CardContent>
      </Card>

      {/* ── 3. Future improvements ── */}
      <Card className="border-0 shadow-lg">
        <CardHeader className="border-b bg-muted/30">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[var(--unicare-orange)]/10 rounded-lg">
              <MessageSquare className="w-5 h-5 text-[var(--unicare-orange)]" />
            </div>
            <div>
              <CardTitle className="text-lg text-[var(--unicare-navy)]">향후 개선 사항</CardTitle>
              <CardDescription>
                다음 상담을 위한 액션 아이템과 개선점을 기록하세요
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-3">
            <Label className="text-[var(--unicare-navy)] font-semibold text-base flex items-center gap-2">
              <div className="p-1.5 bg-[var(--unicare-navy)]/10 rounded-lg">
                <ClipboardCheck className="w-4 h-4 text-[var(--unicare-navy)]" />
              </div>
              액션 아이템 & 권고 사항
            </Label>
            <Textarea
              placeholder="향후 개선 사항, 후속 조치, 추천 프로그램, 다음 상담 일정, 기타 지속적 개선을 위한 메모를 남겨 주세요..."
              value={data.futureImprovements}
              onChange={(e) => onChange({ ...data, futureImprovements: e.target.value })}
              className={cn(
                "min-h-[150px] rounded-xl border-2 p-4 text-base resize-none",
                "focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]",
                "placeholder:text-gray-400"
              )}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
