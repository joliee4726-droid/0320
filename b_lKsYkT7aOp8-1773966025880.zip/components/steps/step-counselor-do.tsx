"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import {
  ClipboardList,
  Lock,
  Brain,
  FileText,
  Link2,
  ShieldCheck,
  TrendingUp,
  Briefcase,
  MessageSquare,
  Star,
  Sparkles,
  AlertCircle,
  RefreshCw,
} from "lucide-react"
import { cn } from "@/lib/utils"

type SignalType = "red" | "yellow" | "blue" | "other" | null

interface UploadFile {
  name: string
  size: number
  type: string
}

interface CounselorDoData {
  counselingNotes: string
  linkedPrograms: string
  aiVerified: boolean
}

interface StepCounselorDoProps {
  data: CounselorDoData
  onChange: (data: CounselorDoData) => void
  signal: SignalType
  uploadData: {
    jobcarePdf: UploadFile | null
    resume: UploadFile | null
  }
  counselingMeta?: {
    sessionCount: number
    counselingType: string
    date: string
    startTime: string
    endTime: string
  }
  onMetaChange?: (meta: any) => void
}

interface AIAnalysisResult {
  scores: {
    careerClarity: number
    goalAlignment: number
    skillMatch: number
    marketReadiness: number
  }
  recommendations: string[]
  summary: string
  keyInsights: string[]
}

const getSignalContext = (signal: SignalType): string => {
  switch (signal) {
    case "red":
      return "Red signal - career direction unclear"
    case "yellow":
      return "Yellow signal - no strategy defined"
    case "blue":
      return "Blue signal - skill development needed"
    default:
      return "General career analysis"
  }
}

async function analyzeWithMock(signal: SignalType): Promise<AIAnalysisResult> {
  await new Promise((resolve) => setTimeout(resolve, 2000))

  const signalScores = {
    red: { careerClarity: 35, goalAlignment: 40, skillMatch: 55, marketReadiness: 30 },
    yellow: { careerClarity: 65, goalAlignment: 45, skillMatch: 60, marketReadiness: 50 },
    blue: { careerClarity: 80, goalAlignment: 75, skillMatch: 45, marketReadiness: 60 },
    other: { careerClarity: 55, goalAlignment: 55, skillMatch: 55, marketReadiness: 55 },
  }

  const scores = signal ? signalScores[signal] : signalScores.other

  return {
    scores,
    recommendations: [
      "추천 프로그램 1",
      "추천 프로그램 2",
      "추천 프로그램 3",
      "추천 프로그램 4",
    ],
    summary: "학생의 진로 상담을 완료했습니다.",
    keyInsights: [
      "주요 인사이트 1",
      "주요 인사이트 2",
      "주요 인사이트 3",
    ],
  }
}

export function StepCounselorDo({
  data,
  onChange,
  signal,
  uploadData,
  counselingMeta,
  onMetaChange,
}: StepCounselorDoProps) {
  const [aiResult, setAiResult] = useState<AIAnalysisResult | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isLocked, setIsLocked] = useState(true)
  const [passwordAttempt, setPasswordAttempt] = useState("")
  const [passwordError, setPasswordError] = useState("")
  const [editingSessionCount, setEditingSessionCount] = useState(false)
  const [tempSessionCount, setTempSessionCount] = useState(
    counselingMeta?.sessionCount || 1
  )

  const ADMIN_PASSWORD = "unicare2024"

  const handlePasswordSubmit = () => {
    setPasswordError("")
    if (passwordAttempt === ADMIN_PASSWORD) {
      setIsLocked(false)
      setPasswordAttempt("")
    } else {
      setPasswordError("비밀번호가 일치하지 않습니다")
      setPasswordAttempt("")
    }
  }

  const getSignalLabel = () => {
    switch (signal) {
      case "red":
        return { label: "Unknown Path", color: "text-red-600", bg: "bg-red-100" }
      case "yellow":
        return { label: "No Strategy", color: "text-yellow-600", bg: "bg-yellow-100" }
      case "blue":
        return { label: "Skill Lack", color: "text-blue-600", bg: "bg-blue-100" }
      default:
        return { label: "Custom", color: "text-gray-600", bg: "bg-gray-100" }
    }
  }

  const signalInfo = getSignalLabel()

  const handleAnalyze = useCallback(async () => {
    setIsAnalyzing(true)
    setError(null)

    try {
      const result = await analyzeWithMock(signal)
      setAiResult(result)

      if (!data.counselingNotes && result.summary) {
        onChange({
          ...data,
          counselingNotes: result.summary,
        })
      }
    } catch (err) {
      console.error("분석 실패:", err)
      setError("분석 중 오류가 발생했습니다")
    } finally {
      setIsAnalyzing(false)
    }
  }, [signal, data, onChange])

  return (
    <div className="space-y-6">
      {/* Lock screen */}
      {isLocked && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md border-0 shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-[var(--unicare-navy)] to-blue-900 rounded-t-xl text-white">
              <div className="flex items-center gap-3">
                <Lock className="w-6 h-6" />
                <div>
                  <CardTitle className="text-2xl">관리자 전용</CardTitle>
                  <CardDescription className="text-white/80">
                    상담자 비밀번호 입력
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-8 space-y-6">
              <Input
                type="password"
                value={passwordAttempt}
                onChange={(e) => {
                  setPasswordAttempt(e.target.value)
                  setPasswordError("")
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handlePasswordSubmit()
                }}
                placeholder="비밀번호 입력"
                className="h-12 rounded-xl border-2 text-center text-lg"
              />
              {passwordError && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">{passwordError}</span>
                </div>
              )}
              <Button
                onClick={handlePasswordSubmit}
                className="w-full h-11 bg-[var(--unicare-orange)] hover:bg-orange-600 text-white font-semibold rounded-xl"
              >
                접근 권한 확인
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main content */}
      {!isLocked && (
        <>
          {/* Header */}
          <div className="flex items-center justify-between p-4 rounded-xl bg-[var(--unicare-navy)] text-white">
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-5 h-5" />
              <span className="font-medium">상담자 세션 활성화</span>
            </div>
            <div
              className={cn(
                "px-3 py-1 rounded-full text-sm font-semibold",
                signalInfo.bg,
                signalInfo.color
              )}
            >
              Signal: {signalInfo.label}
            </div>
          </div>

          {/* Session Metadata */}
          {counselingMeta && onMetaChange && (
            <Card className="border-2 border-orange-100 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between border-b pb-4">
                  <div className="flex items-center gap-2">
                    <div className="px-3 py-1 bg-[var(--unicare-navy)] text-white rounded-full text-sm font-bold">
                      {counselingMeta.sessionCount}회차
                    </div>
                    <p className="text-xs text-gray-400">자동 카운트됨</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingSessionCount(!editingSessionCount)}
                    className="text-xs text-gray-500 underline"
                  >
                    {editingSessionCount ? "완료" : "수정"}
                  </Button>
                </div>

                {editingSessionCount && (
                  <div className="p-4 bg-blue-50 rounded-xl border border-blue-200 space-y-3">
                    <Label className="font-semibold text-blue-900">회차 번호 수정</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        min="1"
                        value={tempSessionCount}
                        onChange={(e) => setTempSessionCount(parseInt(e.target.value) || 1)}
                        className="border-2"
                      />
                      <Button
                        onClick={() => {
                          if (onMetaChange) {
                            onMetaChange({
                              ...counselingMeta,
                              sessionCount: tempSessionCount,
                            })
                          }
                          setEditingSessionCount(false)
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        저장
                      </Button>
                    </div>
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <Label className="text-sm font-bold text-[var(--unicare-navy)]">
                      상담 형태
                    </Label>
                    <div className="flex gap-2">
                      {["대면", "비대면"].map((type) => (
                        <button
                          key={type}
                          onClick={() =>
                            onMetaChange({
                              ...counselingMeta,
                              counselingType: type,
                            })
                          }
                          className={cn(
                            "flex-1 py-2 px-3 rounded-lg font-medium border-2 transition-all",
                            counselingMeta.counselingType === type
                              ? "bg-[var(--unicare-navy)] text-white border-[var(--unicare-navy)]"
                              : "bg-white text-gray-500 border-gray-200"
                          )}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                    <Input
                      type="date"
                      value={counselingMeta.date}
                      onChange={(e) =>
                        onMetaChange({
                          ...counselingMeta,
                          date: e.target.value,
                        })
                      }
                      className="h-10 rounded-lg border-2"
                    />
                  </div>

                  <div className="space-y-4">
                    <Label className="text-sm font-bold text-blue-900">
                      시간 기록
                    </Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <p className="text-xs text-blue-700 font-semibold mb-1">
                          시작
                        </p>
                        <Input
                          type="time"
                          value={counselingMeta.startTime}
                          onChange={(e) =>
                            onMetaChange({
                              ...counselingMeta,
                              startTime: e.target.value,
                            })
                          }
                          className="h-10 rounded-lg border-2"
                        />
                      </div>
                      <div>
                        <p className="text-xs text-blue-700 font-semibold mb-1">
                          종료
                        </p>
                        <Input
                          type="time"
                          value={counselingMeta.endTime}
                          onChange={(e) =>
                            onMetaChange({
                              ...counselingMeta,
                              endTime: e.target.value,
                            })
                          }
                          className="h-10 rounded-lg border-2"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* AI Analysis Card */}
          <Card className="border-0 shadow-lg">
            <CardHeader className="border-b bg-gradient-to-r from-[var(--unicare-navy)] to-blue-900 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Brain className="w-6 h-6" />
                  <div>
                    <CardTitle>AI 분석</CardTitle>
                    <CardDescription className="text-white/80">
                      신호 기반 AI 분석 결과
                    </CardDescription>
                  </div>
                </div>
                <Button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl font-semibold bg-[var(--unicare-orange)] hover:bg-orange-600 text-white"
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      분석 중...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      {aiResult ? "재분석" : "분석 시작"}
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              {error && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-sm">
                  {error}
                </div>
              )}
              {aiResult && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {Object.entries(aiResult.scores).map(([key, value]) => (
                      <div key={key} className="p-3 rounded-lg bg-gray-50 border">
                        <p className="text-xs text-gray-600 font-semibold mb-1">
                          {key}
                        </p>
                        <p className="text-2xl font-bold text-[var(--unicare-navy)]">
                          {value}
                        </p>
                      </div>
                    ))}
                  </div>
                  <div className="p-4 rounded-lg bg-blue-50 border">
                    <h4 className="font-semibold text-[var(--unicare-navy)] mb-2">
                      요약
                    </h4>
                    <p className="text-sm text-gray-700">{aiResult.summary}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Counselor Notes */}
          <Card className="border-0 shadow-lg">
            <CardHeader className="border-b bg-muted/30">
              <div className="flex items-center gap-3">
                <MessageSquare className="w-5 h-5 text-[var(--unicare-navy)]" />
                <div>
                  <CardTitle className="text-lg text-[var(--unicare-navy)]">
                    상담 노트
                  </CardTitle>
                  <CardDescription>관찰사항 및 권장사항 기록</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="space-y-3">
                <Label className="text-[var(--unicare-navy)] font-semibold">
                  상담 내용
                </Label>
                <Textarea
                  placeholder="상담 내용을 입력해주세요..."
                  value={data.counselingNotes}
                  onChange={(e) =>
                    onChange({ ...data, counselingNotes: e.target.value })
                  }
                  className="min-h-[150px] rounded-xl border-2 p-4 resize-none"
                />
              </div>

              <div className="space-y-3">
                <Label className="text-[var(--unicare-navy)] font-semibold">
                  연계 프로그램
                </Label>
                <Input
                  placeholder="예: 프로그램1, 프로그램2"
                  value={data.linkedPrograms}
                  onChange={(e) =>
                    onChange({ ...data, linkedPrograms: e.target.value })
                  }
                  className="h-12 rounded-lg border-2"
                />
              </div>

              <div className="p-4 rounded-xl bg-green-50 border border-green-200">
                <div className="flex items-start gap-4">
                  <Checkbox
                    id="aiVerified"
                    checked={data.aiVerified}
                    onCheckedChange={(checked) =>
                      onChange({
                        ...data,
                        aiVerified: checked as boolean,
                      })
                    }
                    className="mt-1 h-5 w-5"
                  />
                  <div className="flex-1">
                    <Label
                      htmlFor="aiVerified"
                      className="text-green-800 font-semibold flex items-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck className="w-5 h-5" />
                      AI 분석 검증 완료
                    </Label>
                    <p className="text-sm text-green-700 mt-1">
                      AI 분석 결과를 검토하고 확인했습니다
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
