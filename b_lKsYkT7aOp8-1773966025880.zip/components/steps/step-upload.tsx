"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, FileText, X, CheckCircle2, CloudUpload, AlertCircle, Lock, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

interface UploadFile {
  name: string
  size: number
  type: string
}

interface UploadData {
  jobcarePdf: UploadFile | null
  resume: UploadFile | null
}

type SignalType = "red" | "yellow" | "blue" | "other" | null

interface StepUploadProps {
  data: UploadData
  onChange: (data: UploadData) => void
  signal: SignalType
}

interface DropZoneProps {
  label: string
  description: string
  accept: string
  file: UploadFile | null
  onFileChange: (file: UploadFile | null) => void
  icon: "jobcare" | "resume"
  inputId: string
}

// ──────────────────────────────────────────────
// DropZone (active upload area)
// ──────────────────────────────────────────────
function DropZone({ label, description, accept, file, onFileChange, icon, inputId }: DropZoneProps) {
  const [isDragging, setIsDragging] = useState(false)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      const droppedFile = e.dataTransfer.files[0]
      if (droppedFile && droppedFile.type === "application/pdf") {
        onFileChange({ name: droppedFile.name, size: droppedFile.size, type: droppedFile.type })
        const input = document.getElementById(inputId) as HTMLInputElement | null
        if (input) {
          const dt = new DataTransfer()
          dt.items.add(droppedFile)
          input.files = dt.files
        }
      }
    },
    [onFileChange, inputId]
  )

  const handleFileSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const selectedFile = e.target.files?.[0]
      if (selectedFile) {
        onFileChange({ name: selectedFile.name, size: selectedFile.size, type: selectedFile.type })
      }
    },
    [onFileChange]
  )

  const handleRemove = () => {
    onFileChange(null)
    const input = document.getElementById(inputId) as HTMLInputElement | null
    if (input) input.value = ""
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B"
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  const accentColor = icon === "jobcare" ? "text-[var(--unicare-orange)]" : "text-[var(--signal-blue)]"
  const accentBg    = icon === "jobcare" ? "bg-[var(--unicare-orange)]/10" : "bg-[var(--signal-blue)]/10"

  return (
    <div className="flex-1 space-y-3">
      <p className="font-semibold text-base flex items-center gap-2 text-[var(--unicare-navy)]">
        <span className={cn("p-1.5 rounded-lg", accentBg)}>
          <FileText className={cn("w-4 h-4", accentColor)} />
        </span>
        {label}
      </p>

      {file ? (
        <div className="flex items-center gap-4 p-5 rounded-xl border-2 border-green-400 bg-green-50">
          <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-7 h-7 text-green-500" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-green-800 truncate text-sm">{file.name}</p>
            <p className="text-xs text-green-600 mt-0.5">{formatFileSize(file.size)}</p>
          </div>
          <button type="button" onClick={handleRemove} className="p-2 hover:bg-green-200 rounded-lg transition-colors">
            <X className="w-4 h-4 text-green-700" />
          </button>
        </div>
      ) : (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={cn(
            "relative p-8 rounded-xl border-2 border-dashed transition-all duration-300 cursor-pointer group",
            isDragging
              ? "border-[var(--unicare-orange)] bg-orange-50 scale-[1.02]"
              : "border-gray-200 hover:border-[var(--unicare-orange)] hover:bg-orange-50/40"
          )}
        >
          <input
            id={inputId}
            type="file"
            accept={accept}
            onChange={handleFileSelect}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div className="flex flex-col items-center text-center gap-2">
            <div className={cn(
              "w-14 h-14 rounded-full flex items-center justify-center transition-all",
              isDragging
                ? "bg-[var(--unicare-orange)] text-white scale-110"
                : "bg-gray-100 text-gray-400 group-hover:bg-[var(--unicare-orange)]/10 group-hover:text-[var(--unicare-orange)]"
            )}>
              <CloudUpload className={cn("w-7 h-7", isDragging && "animate-bounce")} />
            </div>
            <p className="font-medium text-gray-700 text-sm">
              {isDragging ? "여기에 놓으세요" : "파일을 드래그하거나 클릭하여 업로드"}
            </p>
            <p className="text-xs text-gray-400">{description}</p>
            <span className="mt-1 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[var(--unicare-navy)] text-white text-xs font-semibold hover:bg-[var(--unicare-navy-light)] transition-colors">
              <Upload className="w-3.5 h-3.5" />
              파일 선택
            </span>
          </div>
        </div>
      )}
    </div>
  )
}

// ──────────────────────────────────────────────
// Locked resume zone (shown when signal ≠ blue)
// ──────────────────────────────────────────────
function LockedResumeZone({ signal }: { signal: SignalType }) {
  const signalLabel =
    signal === "red"    ? "진로 방향 미결정" :
    signal === "yellow" ? "전략 부재" :
    signal === "other"  ? "기타" : "신호 미선택"

  return (
    <div className="flex-1 space-y-3">
      {/* Greyed-out label — same layout as DropZone */}
      <p className="font-semibold text-base flex items-center gap-2 text-gray-400">
        <span className="p-1.5 rounded-lg bg-gray-100">
          <FileText className="w-4 h-4 text-gray-400" />
        </span>
        이력서 / 자기소개서
      </p>

      {/* Locked panel */}
      <div className="p-6 rounded-xl border-2 border-dashed border-gray-200 bg-gray-50/60 flex flex-col items-center text-center gap-4">
        {/* Lock icon */}
        <div className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
          <Lock className="w-6 h-6 text-gray-400" />
        </div>

        <div className="space-y-1">
          <p className="font-semibold text-gray-500 text-sm">이력서 코칭 미제공 단계</p>
          <p className="text-xs text-gray-400 leading-relaxed max-w-[260px]">
            이력서 분석은{" "}
            <span className="font-semibold text-[var(--signal-blue)]">취업 스킬 부족</span>{" "}
            상담 유형에서만 제공됩니다.
          </p>
        </div>

        {/* Current signal chip */}
        {signal && (
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-gray-200 text-xs text-gray-500 font-medium">
            <span>현재 선택:</span>
            <span className="text-[var(--unicare-navy)] font-semibold">{signalLabel}</span>
          </div>
        )}

        {/* Tip */}
        <div className="flex items-start gap-2 px-4 py-3 rounded-lg bg-[var(--signal-blue)]/5 border border-[var(--signal-blue)]/15 text-left w-full">
          <Sparkles className="w-3.5 h-3.5 text-[var(--signal-blue)] mt-0.5 shrink-0" />
          <p className="text-xs text-[var(--signal-blue)]/80 leading-relaxed">
            Step 2로 돌아가{" "}
            <strong>취업 스킬 부족</strong>을 선택하면 이력서 업로드 및 AI 스킬 갭 분석을 받을 수 있습니다.
          </p>
        </div>
      </div>
    </div>
  )
}

// ──────────────────────────────────────────────
// Main export
// ──────────────────────────────────────────────
export function StepUpload({ data, onChange, signal }: StepUploadProps) {
  const isBlue = signal === "blue"

  const signalMeta: Record<string, { label: string; colorClass: string; bgBorder: string; iconColor: string }> = {
    red:    { label: "진로 방향 미결정", colorClass: "text-[var(--signal-red)]",    bgBorder: "bg-red-50 border-[var(--signal-red)]",       iconColor: "text-[var(--signal-red)]" },
    yellow: { label: "전략 부재",        colorClass: "text-[var(--signal-yellow)]", bgBorder: "bg-yellow-50 border-[var(--signal-yellow)]", iconColor: "text-[var(--signal-yellow)]" },
    blue:   { label: "취업 스킬 부족",   colorClass: "text-[var(--signal-blue)]",   bgBorder: "bg-blue-50 border-[var(--signal-blue)]",     iconColor: "text-[var(--signal-blue)]" },
    other:  { label: "기타",             colorClass: "text-gray-600",               bgBorder: "bg-gray-50 border-gray-300",                 iconColor: "text-gray-500" },
  }
  const meta = signal ? signalMeta[signal] : null

  return (
    <Card className="border-0 shadow-lg">
      {/* ── Header — matches StepCounselorDo exactly ── */}
      <CardHeader className="border-b bg-gradient-to-r from-[var(--unicare-navy)] to-[var(--unicare-navy-light)] rounded-t-xl text-white">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/10 rounded-lg">
            <Upload className="w-6 h-6" />
          </div>
          <div>
            <CardTitle className="text-xl">서류 업로드</CardTitle>
            <CardDescription className="text-white/80">
              상담 목적에 따라 필요한 서류를 업로드하세요
            </CardDescription>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-8 space-y-8">
        {/* ── Signal guidance banner ── */}
        {meta ? (
          <div className={cn("flex items-start gap-3 p-4 rounded-xl border-2", meta.bgBorder)}>
            <AlertCircle className={cn("w-5 h-5 mt-0.5 shrink-0", meta.iconColor)} />
            <div>
              <p className={cn("font-semibold mb-0.5", meta.colorClass)}>
                {meta.label} 경로 선택됨
              </p>
              <p className="text-sm text-gray-600">
                {isBlue
                  ? "잡케어 PDF와 이력서를 모두 업로드하면 AI가 스킬 갭을 정밀 분석합니다."
                  : "현재 경로에서는 잡케어 PDF만 업로드하면 됩니다. 이력서 코칭은 취업 스킬 부족 상담 시 제공됩니다."}
              </p>
            </div>
          </div>
        ) : (
          <div className="flex items-start gap-3 p-4 rounded-xl border-2 bg-gray-50 border-gray-300">
            <AlertCircle className="w-5 h-5 mt-0.5 shrink-0 text-gray-400" />
            <p className="text-sm text-gray-500">
              Step 2로 돌아가 상담 목적(Signal)을 먼저 선택해 주세요.
            </p>
          </div>
        )}

        {/* ── Upload zones: always 2-column grid ── */}
        <div className="grid gap-8 md:grid-cols-2">
          {/* JobCare PDF — always active */}
          <DropZone
            label="잡케어 직업설계서 PDF (필수)"
            description="잡케어 적성검사 결과 PDF (PDF만 가능)"
            accept=".pdf"
            file={data.jobcarePdf}
            onFileChange={(file) => onChange({ ...data, jobcarePdf: file })}
            icon="jobcare"
            inputId="jobcare-file-input"
          />

          {/* Resume — active for blue, locked for everything else */}
          {isBlue ? (
            <div className="relative">
              <div className="absolute -top-2 -right-2 z-10 flex items-center gap-1 px-3 py-1 bg-[var(--signal-blue)] text-white text-xs font-semibold rounded-full shadow-md">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                스킬 경로 필수
              </div>
              <DropZone
                label="이력서 / 자기소개서"
                description="스킬 갭 분석을 위해 업로드하세요 (PDF만 가능)"
                accept=".pdf"
                file={data.resume}
                onFileChange={(file) => onChange({ ...data, resume: file })}
                icon="resume"
                inputId="resume-file-input"
              />
            </div>
          ) : (
            <LockedResumeZone signal={signal} />
          )}
        </div>

        {/* ── Status summary ── */}
        <div className="space-y-2.5">
          {/* JobCare row */}
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
            <div className={cn("w-7 h-7 rounded-full flex items-center justify-center shrink-0",
              data.jobcarePdf ? "bg-green-100" : "bg-gray-100")}>
              {data.jobcarePdf
                ? <CheckCircle2 className="w-4 h-4 text-green-600" />
                : <div className="w-2.5 h-2.5 rounded-full border-2 border-gray-400" />}
            </div>
            <div className="flex-1">
              <p className="font-medium text-xs text-[var(--unicare-navy)]">잡케어 직업설계서 PDF</p>
              <p className="text-xs text-gray-400">모든 학생 필수</p>
            </div>
            <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full",
              data.jobcarePdf ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500")}>
              {data.jobcarePdf ? "업로드 완료" : "대기 중"}
            </span>
          </div>

          {/* Resume row */}
          <div className={cn("flex items-center gap-3 p-3 rounded-lg transition-all",
            isBlue ? "bg-blue-50" : "bg-muted/30 opacity-60")}>
            <div className={cn("w-7 h-7 rounded-full flex items-center justify-center shrink-0",
              data.resume && isBlue ? "bg-green-100" : isBlue ? "bg-blue-100" : "bg-gray-100")}>
              {data.resume && isBlue
                ? <CheckCircle2 className="w-4 h-4 text-green-600" />
                : isBlue
                  ? <div className="w-2.5 h-2.5 rounded-full border-2 border-[var(--signal-blue)]" />
                  : <Lock className="w-3.5 h-3.5 text-gray-400" />}
            </div>
            <div className="flex-1">
              <p className="font-medium text-xs text-[var(--unicare-navy)]">이력서 / 자기소개서</p>
              <p className="text-xs text-gray-400">
                {isBlue ? "취업 스킬 부족 경로 필수" : "현재 경로에서 불필요"}
              </p>
            </div>
            <span className={cn("text-xs font-semibold px-2.5 py-1 rounded-full",
              !isBlue          ? "bg-gray-100 text-gray-400" :
              data.resume      ? "bg-green-100 text-green-700" :
                                 "bg-blue-100 text-[var(--signal-blue)]")}>
              {!isBlue ? "미해당" : data.resume ? "업로드 완료" : "대기 중"}
            </span>
          </div>
        </div>

        {/* ── JobCare info footer ── */}
        <div className="p-4 rounded-xl bg-[var(--unicare-navy)]/5 border border-[var(--unicare-navy)]/10">
          <div className="flex items-start gap-3">
            <div className="p-1.5 bg-[var(--unicare-navy)]/10 rounded-lg mt-0.5">
              <FileText className="w-4 h-4 text-[var(--unicare-navy)]" />
            </div>
            <div>
              <h4 className="font-semibold text-[var(--unicare-navy)] text-sm mb-1">잡케어 직업설계서란?</h4>
              <p className="text-xs text-gray-500 leading-relaxed">
                잡케어(JobCare)는 국가 고용 지원 시스템의 종합 직업 적성 검사 서비스입니다.
                아직 검사를 완료하지 않으셨다면 잡케어 포털에 접속하여 보고서를 생성해 주세요.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
