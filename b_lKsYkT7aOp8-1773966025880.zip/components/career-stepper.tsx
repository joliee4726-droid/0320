"use client"

import { cn } from "@/lib/utils"
import { Check } from "lucide-react"

interface Step {
  id: number
  label: string
}

interface CareerStepperProps {
  currentStep: number
  steps: Step[]
}

export function CareerStepper({ currentStep, steps }: CareerStepperProps) {
  return (
    <div className="flex items-center justify-between py-6 px-4">
      {steps.map((step, index) => {
        const isCompleted = currentStep > step.id
        const isCurrent = currentStep === step.id
        const isLast = index === steps.length - 1

        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            {/* Step circle */}
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm transition-all",
                  isCompleted
                    ? "bg-[var(--unicare-navy)] text-white"
                    : isCurrent
                      ? "bg-[var(--unicare-orange)] text-white shadow-lg scale-110"
                      : "bg-gray-200 text-gray-500"
                )}
              >
                {isCompleted ? (
                  <Check className="w-5 h-5" />
                ) : (
                  step.id
                )}
              </div>
              <span
                className={cn(
                  "mt-2 text-xs font-medium text-center max-w-[80px]",
                  isCurrent
                    ? "text-[var(--unicare-orange)]"
                    : isCompleted
                      ? "text-[var(--unicare-navy)]"
                      : "text-gray-400"
                )}
              >
                {step.label}
              </span>
            </div>

            {/* Connector line */}
            {!isLast && (
              <div className="flex-1 mx-2 mt-[-20px]">
                <div
                  className={cn(
                    "h-1 rounded-full transition-all",
                    isCompleted ? "bg-[var(--unicare-navy)]" : "bg-gray-200"
                  )}
                />
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
