"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  LogOut,
  Download,
  Plus,
  AlertCircle,
  Play,
  CheckCircle,
  Clock,
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { StudentRecord } from "@/lib/student-data"
import {
  INITIAL_STUDENTS,
  filterStudentsByCounselor,
  assignStudentToCounselor,
  updateStudentStatus,
} from "@/lib/student-data"

interface CounselorSession {
  counselorName: string
  isMasterMode: boolean
  loginTime: string
}

const signalColors = {
  red: "bg-red-100 text-red-800",
  yellow: "bg-yellow-100 text-yellow-800",
  blue: "bg-blue-100 text-blue-800",
}

const signalLabels = {
  red: "진로 불명확",
  yellow: "전략 부재",
  blue: "역량 부족",
}

const statusIcons = {
  "미배정": <AlertCircle className="w-4 h-4" />,
  "진행중": <Clock className="w-4 h-4" />,
  "완료": <CheckCircle className="w-4 h-4" />,
}

export default function DashboardPage() {
  const router = useRouter()
  const [session, setSession] = useState<CounselorSession | null>(null)
  const [students, setStudents] = useState<StudentRecord[]>(INITIAL_STUDENTS)
  const [filteredStudents, setFilteredStudents] = useState<StudentRecord[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStudent, setSelectedStudent] = useState<StudentRecord | null>(null)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)

  // Load session from localStorage
  useEffect(() => {
    const sessionData = localStorage.getItem("counselorSession")
    if (!sessionData) {
      router.push("/")
      return
    }

    const parsedSession = JSON.parse(sessionData) as CounselorSession
    setSession(parsedSession)

    // Filter students based on counselor
    const filtered = filterStudentsByCounselor(
      students,
      parsedSession.counselorName,
      parsedSession.isMasterMode
    )
    setFilteredStudents(filtered)
  }, [students, router])

  // Search filter
  useEffect(() => {
    const query = searchQuery.toLowerCase()
    const result = filteredStudents.filter(
      (student) =>
        student.name.toLowerCase().includes(query) ||
        student.studentId.includes(query) ||
        student.major.toLowerCase().includes(query)
    )
    setFilteredStudents(result)
  }, [searchQuery])

  const handleLogout = () => {
    localStorage.removeItem("counselorSession")
    router.push("/")
  }

  const handleStartCounseling = (student: StudentRecord) => {
    if (student.assignedCounselor !== "미배정" && student.assignedCounselor !== session?.counselorName) {
      alert(`이 학생은 이미 ${student.assignedCounselor} 상담사에게 배정되었습니다.`)
      return
    }

    setSelectedStudent(student)
    setShowConfirmDialog(true)
  }

  const confirmStartCounseling = () => {
    if (!selectedStudent || !session) return

    // Assign student to this counselor
    const updated = assignStudentToCounselor(students, selectedStudent.id, session.counselorName)
    setStudents(updated)

    // Refresh filtered list
    const filtered = filterStudentsByCounselor(
      updated,
      session.counselorName,
      session.isMasterMode
    )
    setFilteredStudents(filtered)

    setShowConfirmDialog(false)
    setSelectedStudent(null)
  }

  const handleExportAll = () => {
    const csvHeader = [
      "학생명",
      "학번",
      "학과",
      "학년",
      "성별",
      "평점",
      "신호",
      "상태",
      "담당상담사",
      "회차",
      "신청일",
    ]

    const csvRows = filteredStudents.map((student) => [
      student.name,
      student.studentId,
      student.major,
      student.grade,
      student.gender,
      student.gpa,
      signalLabels[student.signal],
      student.status,
      student.assignedCounselor,
      student.sessionCount,
      student.createdDate,
    ])

    const csvContent = [
      csvHeader.join(","),
      ...csvRows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
    ].join("\n")

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `UNICARE_학생리스트_${session?.counselorName || "상담사"}.csv`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  if (!session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">로딩 중...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-[var(--unicare-navy)] mb-2">
              {session.isMasterMode ? "마스터 대시보드" : `${session.counselorName} 대시보드`}
            </h1>
            <p className="text-gray-600">
              {session.isMasterMode ? "모든 상담사의 학생 데이터" : "귀하의 상담 학생 리스트"}
            </p>
          </div>
          <div className="flex gap-2">
            {session.isMasterMode && (
              <Badge className="bg-amber-100 text-amber-900 px-3 py-1">
                마스터 모드
              </Badge>
            )}
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-red-200 text-red-600 hover:bg-red-50"
            >
              <LogOut className="w-4 h-4 mr-2" />
              로그아웃
            </Button>
          </div>
        </div>

        {/* Info Alert */}
        {!session.isMasterMode && (
          <Alert className="border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4 text-blue-900" />
            <AlertDescription className="text-blue-900">
              미배정 학생을 선택하여 상담을 시작할 수 있습니다. 상담 시작 시 해당 학생이 귀하에게 배정됩니다.
            </AlertDescription>
          </Alert>
        )}

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-2">
                <p className="text-sm text-gray-600">전체 학생 수</p>
                <p className="text-3xl font-bold text-[var(--unicare-navy)]">
                  {filteredStudents.length}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="space-y-2">
                <p className="text-sm text-gray-600">미배정</p>
                <p className="text-3xl font-bold text-amber-600">
                  {filteredStudents.filter((s) => s.status === "미배정").length}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="space-y-2">
                <p className="text-sm text-gray-600">진행중</p>
                <p className="text-3xl font-bold text-blue-600">
                  {filteredStudents.filter((s) => s.status === "진행중").length}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="space-y-2">
                <p className="text-sm text-gray-600">완료</p>
                <p className="text-3xl font-bold text-green-600">
                  {filteredStudents.filter((s) => s.status === "완료").length}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Actions */}
        <div className="flex gap-4">
          <Input
            placeholder="학생명, 학번, 학과로 검색..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 rounded-xl border-2"
          />
          <Button
            onClick={handleExportAll}
            className="bg-[var(--unicare-orange)] hover:bg-[var(--unicare-orange-light)] text-white rounded-xl px-6"
          >
            <Download className="w-4 h-4 mr-2" />
            엑셀 다운로드
          </Button>
        </div>

        {/* Students Table */}
        <Card>
          <CardHeader>
            <CardTitle>학생 리스트</CardTitle>
            <CardDescription>
              클릭하여 상담을 시작하거나 상담 진행 상황을 확인할 수 있습니다
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-[var(--unicare-navy)]/20 bg-gray-50">
                    <TableHead className="font-bold text-[var(--unicare-navy)]">학생명</TableHead>
                    <TableHead className="font-bold text-[var(--unicare-navy)]">학번</TableHead>
                    <TableHead className="font-bold text-[var(--unicare-navy)]">학과</TableHead>
                    <TableHead className="font-bold text-[var(--unicare-navy)]">신호</TableHead>
                    <TableHead className="font-bold text-[var(--unicare-navy)]">상태</TableHead>
                    <TableHead className="font-bold text-[var(--unicare-navy)]">담당상담사</TableHead>
                    <TableHead className="font-bold text-[var(--unicare-navy)]">회차</TableHead>
                    <TableHead className="text-right font-bold text-[var(--unicare-navy)]">작업</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                        해당하는 학생이 없습니다
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredStudents.map((student) => (
                      <TableRow
                        key={student.id}
                        className="border-b border-gray-200 hover:bg-gray-50 transition-colors"
                      >
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell className="text-gray-600">{student.studentId}</TableCell>
                        <TableCell className="text-gray-600">{student.major}</TableCell>
                        <TableCell>
                          <Badge className={cn("text-xs", signalColors[student.signal])}>
                            {signalLabels[student.signal]}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {statusIcons[student.status]}
                            <span className="text-sm">{student.status}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className={cn(
                            "text-sm px-2 py-1 rounded",
                            student.assignedCounselor === "미배정"
                              ? "bg-gray-100 text-gray-600"
                              : "bg-blue-100 text-blue-900 font-medium"
                          )}>
                            {student.assignedCounselor}
                          </span>
                        </TableCell>
                        <TableCell className="text-center font-medium">
                          {student.sessionCount}
                        </TableCell>
                        <TableCell className="text-right">
                          {student.status === "미배정" || student.assignedCounselor === session.counselorName ? (
                            <Button
                              size="sm"
                              onClick={() => handleStartCounseling(student)}
                              className="bg-green-600 hover:bg-green-700 text-white"
                            >
                              <Play className="w-4 h-4" />
                            </Button>
                          ) : (
                            <span className="text-xs text-gray-400">배정됨</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle>상담 시작</DialogTitle>
            <DialogDescription>
              {selectedStudent?.name} 학생과의 상담을 시작하시겠습니까?
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-900">
                <span className="font-semibold">학번:</span> {selectedStudent?.studentId}
              </p>
              <p className="text-sm text-blue-900">
                <span className="font-semibold">학과:</span> {selectedStudent?.major}
              </p>
              <p className="text-sm text-blue-900">
                <span className="font-semibold">신호:</span> {selectedStudent && signalLabels[selectedStudent.signal]}
              </p>
            </div>
            <p className="text-sm text-gray-600">
              상담 시작 후 해당 학생은 귀하에게 배정되며 다른 상담사의 리스트에서 제외됩니다.
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => setShowConfirmDialog(false)}
              variant="outline"
              className="flex-1"
            >
              취소
            </Button>
            <Button
              onClick={confirmStartCounseling}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            >
              상담 시작
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
