"use client"

import { useRouter } from "next/navigation"
import { useEffect } from "react"

export default function HomePage() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to the unified form page
    router.push("/student")
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-[var(--unicare-navy)] mb-4">UNICARE</h1>
        <p className="text-gray-600">로딩 중...</p>
      </div>
    </div>
  )
}

