"use client"

import { useState } from "react"
import { CareerStepper } from "@/components/career-stepper"
import { StepProfile } from "@/components/steps/step-profile"
import { StepSignal } from "@/components/steps/step-signal"
import { StepUpload } from "@/components/steps/step-upload"
import { StepCounselorDo } from "@/components/steps/step-counselor-do"
import { StepPDCACheck } from "@/components/steps/step-pdca-check"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Download, Lock, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import { COUNSELORS, validateCounselorLogin } from "@/lib/counselor-auth"

const GOOGLE_SHEETS_URL = process.env.NEXT_PUBLIC_GOOGLE_SHEETS_URL || ""

// 신규 학생용 스텝
const stepsNew = [
  { id: 1, label: "기본 정보" },
  { id: 2, label: "진로 신호" },
  { id: 3, label: "자료 업로드" },
  { id: 4, label: "상담자 분석" },
  { id: 5, label: "만족도 평가" },
]

// 기존 학생용 스텝 (간소화)
const stepsExisting = [
  { id: 1, label: "기본 정보" },
  { id: 3, label: "자료 업로드" },
]

const sendToGoogleSheets = async (data: any) => {
  if (!GOOGLE_SHEETS_URL) {
    console.warn("[v0] Google Sheets URL not configured")
    return false
  }
  try {
    await fetch(GOOGLE_SHEETS_URL, {
      method: "POST",
      body: JSON.stringify(data),
      mode: "no-cors",
    })
    console.log("[v0] Google Sheets submission sent successfully")
    return true
  } catch (error) {
    console.error("[v0] Failed to send to Google Sheets:", error)
    return false
  }
}

export default function UnifiedPage() {
  const [currentStep, setCurrentStep] = useState(0)
  const [userType, setUserType] = useState<"new" | "existing" | null>(null)

  // Form states
  const [profileData, setProfileData] = useState({
    userStatus: "" as "new" | "existing" | "",
    targetType: "" as "재학생" | "졸업생" | "지역청년" | "",
    name: "",
    studentId: "",
    major: "",
    doubleMajor: "",
    minor: "",
    grade: "",
    gpa: "",
    phone: "",
    referralPath: "",
    gender: "",
    academicStatus: "",
    graduationDate: "",
    educationLevel: "",
    residenceRegion: "",
  })

  const [signalData, setSignalData] = useState({ signal: "", signalDetails: "" })
  const [uploadData, setUploadData] = useState({ resumeUrl: "", portfolioUrl: "", certifications: "" })
  const [counselorDoData, setCounselorDoData] = useState({
    analysis: "",
    recommendations: "",
    actionPlan: "",
    aiVerified: false,
  })
  const [pdcaCheckData, setPdcaCheckData] = useState({
    satisfactionScore: 0,
    feedbackText: "",
    followUpDate: "",
  })
  const [counselingMeta, setCounselingMeta] = useState({
    sessionCount: "1회",
    date: new Date().toISOString().split("T")[0],
    counselingType: "면접",
    startTime: new Date().toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit" }),
    endTime: "",
  })

  // Admin states
  const [adminPassword, setAdminPassword] = useState("")
  const [selectedCounselor, setSelectedCounselor] = useState("")
  const [loginError, setLoginError] = useState("")
  const [loggedInCounselor, setLoggedInCounselor] = useState<string | null>(null)
  const [isMasterMode, setIsMasterMode] = useState(false)
  const [studentSubmissions, setStudentSubmissions] = useState<any[]>([])

  const handleNext = () => {
    // Step 1에서 필수 필드 검증
    if (currentStep === 1) {
      if (!profileData.userStatus) {
        alert("신규/기존을 선택해주세요")
        return
      }
      if (!profileData.name || !profileData.gender || !profileData.phone || !profileData.referralPath) {
        alert("모든 기본 정보를 입력해주세요")
        return
      }
      // 신규 학생: 대상자 유형도 필수
      if (profileData.userStatus === "new" && !profileData.targetType) {
        alert("대상자 유형을 선택해주세요")
        return
      }
    }

    // 기존 학생이 Step 1에서 "다음"을 클릭하면 Step 3으로 직접 이동
    if (currentStep === 1 && profileData.userStatus === "existing") {
      setCurrentStep(3)
    } else if (currentStep < stepsNew.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleLogout = () => {
    setCurrentStep(0)
    setLoggedInCounselor(null)
    setAdminPassword("")
    setSelectedCounselor("")
  }

  const handleStep3Submit = async () => {
    const sheetsData = {
      counselor: loggedInCounselor || "자가상담",
      userType: userType,
      name: profileData.name,
      studentId: profileData.studentId || profileData.educationLevel,
      gender: profileData.gender,
      phone: profileData.phone,
      major: profileData.major || "-",
      academicStatus: profileData.academicStatus || profileData.residenceRegion || "-",
      signalBefore: signalData.signal,
      counselingNote: uploadData.portfolioUrl,
      signalAfter: counselorDoData.recommendations,
      satisfaction: pdcaCheckData.satisfactionScore,
    }

    await sendToGoogleSheets(sheetsData)

    const newSubmission = {
      profile: profileData,
      signal: signalData,
      upload: uploadData,
      counselorAnalysis: counselorDoData,
      pdcaCheck: pdcaCheckData,
      counselingMeta,
      submittedAt: new Date().toLocaleString("ko-KR"),
    }
    setStudentSubmissions([...studentSubmissions, newSubmission])

    // Download CSV
    const csvHeader = [
      "회차",
      "상담일자",
      "상담형태",
      "상담시작",
      "상담종료",
      "유입경로",
      "성명",
      "학번",
      "성별",
      "학년",
      "평점",
      "학적상태",
      "졸업시기",
      "주전공",
      "복수전공",
      "부전공",
      "전화번호",
    ]
    const csvRow = [
      counselingMeta.sessionCount,
      counselingMeta.date,
      counselingMeta.counselingType,
      counselingMeta.startTime,
      counselingMeta.endTime || "미기록",
      profileData.referralPath,
      profileData.name,
      profileData.studentId,
      profileData.gender,
      profileData.grade ? `${profileData.grade}학년` : "",
      profileData.gpa,
      profileData.academicStatus,
      profileData.graduationDate || "N/A",
      profileData.major,
      profileData.doubleMajor || "없음",
      profileData.minor || "없음",
      profileData.phone,
    ]

    const csvContent = [
      csvHeader.join(","),
      csvRow.map((cell) => `"${String(cell || "").replace(/"/g, '""')}"`).join(","),
    ].join("\n")

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `UNICARE_상담보고서_${profileData.name || "학생"}.csv`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    setTimeout(() => {
      setCurrentStep(6)
    }, 800)
  }

  const renderEntryPage = () => (
    <div className="flex flex-col items-center justify-center space-y-8 py-12">
      <h2 className="text-4xl font-bold text-[var(--unicare-navy)] text-balance">
        UNICARE에 오신 것을 환영합니다
      </h2>
      <p className="text-center text-gray-600 max-w-md">학생 상담 신청 또는 상담사 로그인을 선택해주세요</p>

      <div className="grid md:grid-cols-2 gap-8 w-full max-w-2xl">
        <div className="p-8 border-4 border-[var(--unicare-orange)] rounded-3xl bg-orange-50">
          <span className="text-5xl block mb-4">📋</span>
          <h3 className="text-2xl font-bold text-[var(--unicare-orange)] mb-6">학생 상담 신청</h3>
          <p className="text-sm text-gray-600 mb-6">3단계 상담 절차 진행</p>
          <div className="flex flex-col gap-3">
            <button
              onClick={() => {
                setUserType("new")
                setProfileData((prev) => ({ ...prev, userStatus: "new" }))
                setCurrentStep(1)
              }}
              className="px-4 py-3 bg-[var(--unicare-orange)] hover:bg-orange-600 text-white font-semibold rounded-xl transition-all duration-200"
            >
              신규 상담자
            </button>
            <button
              onClick={() => {
                setUserType("existing")
                setProfileData((prev) => ({ ...prev, userStatus: "existing" }))
                setCurrentStep(1)
              }}
              className="px-4 py-3 bg-orange-200 hover:bg-orange-300 text-[var(--unicare-orange)] font-semibold rounded-xl transition-all duration-200"
            >
              기존 상담자
            </button>
          </div>
        </div>

        <button
          onClick={() => setCurrentStep(99)}
          className="p-8 border-4 border-[var(--unicare-navy)] rounded-3xl hover:bg-[var(--unicare-navy)] hover:text-white transition-all duration-300 group"
        >
          <span className="text-5xl block mb-4">🔐</span>
          <h3 className="text-2xl font-bold text-[var(--unicare-navy)] group-hover:text-white">상담사 로그인</h3>
          <p className="text-sm text-gray-600 group-hover:text-white/80 mt-2">관리자 대시보드 접근</p>
        </button>
      </div>
    </div>
  )

  const renderAdminLogin = () => (
    <div className="max-w-md mx-auto">
      <Card>
        <CardHeader className="bg-[var(--unicare-navy)] text-white">
          <CardTitle>상담사 로그인</CardTitle>
          <CardDescription className="text-white/80">관리자 계정으로 로그인하세요</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">상담사 선택</label>
            <Select value={selectedCounselor} onValueChange={setSelectedCounselor}>
              <SelectTrigger>
                <SelectValue placeholder="상담사를 선택하세요" />
              </SelectTrigger>
              <SelectContent>
                {COUNSELORS.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">비밀번호</label>
            <Input
              type="password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              placeholder="비밀번호 입력"
            />
          </div>

          {loginError && <Alert className="bg-red-50 border-red-200"><AlertDescription>{loginError}</AlertDescription></Alert>}

          <Button
            onClick={() => {
              if (validateCounselorLogin(selectedCounselor, adminPassword)) {
                setLoggedInCounselor(selectedCounselor)
                setIsMasterMode(selectedCounselor === "master")
                setCurrentStep(100)
                setLoginError("")
              } else {
                setLoginError("이메일 또는 비밀번호가 올바르지 않습니다")
              }
            }}
            className="w-full bg-[var(--unicare-navy)] hover:bg-[var(--unicare-navy-dark)]"
          >
            <Lock className="w-4 h-4 mr-2" />
            로그인
          </Button>

          <Button onClick={() => setCurrentStep(0)} variant="outline" className="w-full">
            취소
          </Button>
        </CardContent>
      </Card>
    </div>
  )

  const renderAdminDashboard = () => (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-[var(--unicare-navy)]">
              {isMasterMode ? "마스터 대시보드" : `${loggedInCounselor} 대시보드`}
            </h1>
            {isMasterMode && (
              <p className="text-sm text-amber-600 mt-2 font-semibold">모든 상담사의 데이터를 통합 조회하고 있습니다</p>
            )}
          </div>
          <Button onClick={handleLogout} variant="outline" className="h-10 rounded-lg">
            로그아웃
          </Button>
        </div>

        {GOOGLE_SHEETS_URL ? (
          <Alert className="mb-6 border-green-200 bg-green-50">
            <AlertCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              ✓ Google Sheets 통합 활성화: 학생 상담 완료 시 자동으로 데이터가 저장됩니다.
            </AlertDescription>
          </Alert>
        ) : (
          <Alert className="mb-6 border-amber-200 bg-amber-50">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800">
              ⚠ Google Sheets 통합이 설정되지 않았습니다. 대시보드 데이터만 저장됩니다.
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-0 shadow-sm">
          <CardHeader className="bg-gradient-to-r from-[var(--unicare-navy)] to-[var(--unicare-navy-light)] text-white rounded-t-xl">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>학생 관리</CardTitle>
                <CardDescription className="text-white/80">
                  {isMasterMode ? "모든 상담사의 학생 리스트" : "할당된 학생 리스트"}
                </CardDescription>
              </div>
              {studentSubmissions.length > 0 && (
                <Button
                  onClick={() => {
                    const headers = ["성명", "학번", "전공", "성별", "연락처", "대상자", "접수일시", "상태"]
                    const rows = studentSubmissions.map((s) => [
                      s.profile.name,
                      s.profile.studentId || "-",
                      s.profile.major || "-",
                      s.profile.gender || "-",
                      s.profile.phone,
                      s.profile.targetType,
                      s.submittedAt,
                      "완료",
                    ])

                    const csvContent = [
                      headers.join(","),
                      ...rows.map((row) =>
                        row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")
                      ),
                    ].join("\n")

                    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" })
                    const link = document.createElement("a")
                    link.href = URL.createObjectURL(blob)
                    link.download = `UNICARE_학생리스트_${new Date().toISOString().split("T")[0]}.csv`
                    document.body.appendChild(link)
                    link.click()
                    document.body.removeChild(link)
                  }}
                  className="bg-white hover:bg-gray-100 text-[var(--unicare-navy)] font-semibold"
                >
                  <Download className="w-4 h-4 mr-2" />
                  엑셀 다운로드
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-6">
            {studentSubmissions.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 mb-4">현재 제출된 학생이 없습니다.</p>
                <Button onClick={() => setCurrentStep(0)} variant="outline">
                  학생 상담 신청 페이지로
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b-2 border-gray-300">
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">성명</th>
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">학번</th>
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">전공</th>
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">성별</th>
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">연락처</th>
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">대상자</th>
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">접수일시</th>
                      <th className="text-left py-3 px-4 font-bold text-[var(--unicare-navy)]">상태</th>
                    </tr>
                  </thead>
                  <tbody>
                    {studentSubmissions.map((submission, idx) => (
                      <tr key={idx} className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                        <td className="py-3 px-4">{submission.profile.name}</td>
                        <td className="py-3 px-4">{submission.profile.studentId || "-"}</td>
                        <td className="py-3 px-4">{submission.profile.major || "-"}</td>
                        <td className="py-3 px-4">{submission.profile.gender || "-"}</td>
                        <td className="py-3 px-4">{submission.profile.phone}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${
                              submission.profile.targetType === "재학생"
                                ? "bg-blue-100 text-blue-700"
                                : submission.profile.targetType === "졸업생"
                                  ? "bg-green-100 text-green-700"
                                  : "bg-purple-100 text-purple-700"
                            }`}
                          >
                            {submission.profile.targetType}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-gray-600">{submission.submittedAt}</td>
                        <td className="py-3 px-4">
                          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">완료</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )

  const renderCompletionScreen = () => (
    <div className="text-center p-10 bg-white rounded-3xl shadow-xl">
      <div className="text-5xl mb-4">✓</div>
      <h2 className="text-3xl font-bold text-[var(--unicare-navy)] mb-4">신청이 완료되었습니다!</h2>
      <p className="text-gray-600 text-lg mb-2">상담사가 확인 후 성함을 호출할 예정입니다.</p>
      <p className="text-gray-500 mb-8">잠시만 대기해 주세요.</p>

      <div className="space-y-3">
        <p className="text-sm text-gray-600">
          <span className="font-semibold">상담 완료 메일:</span> 등록하신 이메일로 전송됩니다
        </p>
        <p className="text-sm text-gray-600">
          <span className="font-semibold">상담 보고서:</span> 위에서 다운로드한 CSV 파일을 보관해주세요
        </p>
      </div>

      <Button
        onClick={() => {
          setCurrentStep(0)
          setUserType(null)
          setProfileData({
            userStatus: "",
            targetType: "",
            name: "",
            studentId: "",
            major: "",
            doubleMajor: "",
            minor: "",
            grade: "",
            gpa: "",
            phone: "",
            referralPath: "",
            gender: "",
            academicStatus: "",
            graduationDate: "",
            educationLevel: "",
            residenceRegion: "",
          })
          setSignalData({ signal: "", signalDetails: "" })
          setUploadData({ resumeUrl: "", portfolioUrl: "", certifications: "" })
          setCounselorDoData({ analysis: "", recommendations: "", actionPlan: "", aiVerified: false })
          setPdcaCheckData({ satisfactionScore: 0, feedbackText: "", followUpDate: "" })
        }}
        className="mt-8 w-full bg-[var(--unicare-navy)] hover:bg-[var(--unicare-navy-dark)] text-white font-semibold py-6 rounded-xl"
      >
        학생용 메인 화면으로 돌아가기
      </Button>

      <button
        onClick={() => {
          setCurrentStep(0)
          setUserType(null)
          setProfileData({
            userStatus: "",
            targetType: "",
            name: "",
            studentId: "",
            major: "",
            doubleMajor: "",
            minor: "",
            grade: "",
            gpa: "",
            phone: "",
            referralPath: "",
            gender: "",
            academicStatus: "",
            graduationDate: "",
            educationLevel: "",
            residenceRegion: "",
          })
          setSignalData({ signal: "", signalDetails: "" })
          setUploadData({ resumeUrl: "", portfolioUrl: "", certifications: "" })
          setCounselorDoData({ analysis: "", recommendations: "", actionPlan: "", aiVerified: false })
          setPdcaCheckData({ satisfactionScore: 0, feedbackText: "", followUpDate: "" })
        }}
        className="w-full mt-4 text-sm text-gray-400 hover:text-gray-600 underline"
      >
        닫기
      </button>
    </div>
  )

  const renderStep = () => {
    if (currentStep === 0) return renderEntryPage()
    if (currentStep === 99) return renderAdminLogin()
    if (currentStep === 100) return renderAdminDashboard()
    if (currentStep === 6) return renderCompletionScreen()

    switch (currentStep) {
      case 1:
        return <StepProfile data={profileData} onChange={setProfileData} isExistingUser={userType === "existing"} />
      case 2:
        // 기존 학생은 Step 2를 건너뜀
        if (profileData.userStatus === "existing") {
          return <StepUpload data={uploadData} onChange={setUploadData} signal={signalData.signal} />
        }
        return <StepSignal data={signalData} onChange={setSignalData} />
      case 3:
        // 기존 학생은 Step 1에서 정보 입력 후 바로 여기로 옴
        return <StepUpload data={uploadData} onChange={setUploadData} signal={signalData.signal} />
      case 4:
        return (
          <StepCounselorDo
            data={counselorDoData}
            onChange={setCounselorDoData}
            signal={signalData.signal}
            uploadData={uploadData}
            counselingMeta={counselingMeta}
            onMetaChange={setCounselingMeta}
          />
        )
      case 5:
        return <StepPDCACheck data={pdcaCheckData} onChange={setPdcaCheckData} initialSignal={signalData.signal} />
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-5xl mx-auto py-8 px-4">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-[var(--unicare-navy)] mb-2">UNICARE 커리어 상담 시스템</h1>
          <p className="text-gray-600">학생 상담 신청 폼</p>
        </div>

        {/* Stepper - Hidden on step 0, 6, 99, 100 */}
        {currentStep > 0 && currentStep < 6 && currentStep < 99 && (
          <div className="bg-card border-b shadow-sm mb-8">
            <div className="max-w-5xl mx-auto">
              <CareerStepper 
                currentStep={currentStep} 
                steps={profileData.userStatus === "existing" ? stepsExisting : stepsNew} 
              />
            </div>
          </div>
        )}

        {/* Content */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          {renderStep()}
        </div>

        {/* Navigation - Hidden on step 0, 6, 99, 100 */}
        {currentStep > 0 && currentStep < 6 && currentStep < 99 && (
          <div className="mt-8 flex items-center justify-between">
            <Button
              variant="outline"
              size="lg"
              onClick={handlePrevious}
              disabled={currentStep === 1}
              className={cn(
                "px-6 py-6 rounded-xl border-2 transition-all",
                currentStep === 1
                  ? "opacity-50 cursor-not-allowed"
                  : "border-[var(--unicare-navy)] text-[var(--unicare-navy)] hover:bg-[var(--unicare-navy)] hover:text-white"
              )}
            >
              <ChevronLeft className="w-5 h-5 mr-2" />
              이전
            </Button>

            <div className="flex items-center gap-2">
              {(profileData.userStatus === "existing" ? stepsExisting : stepsNew).map((step) => (
                <button
                  key={step.id}
                  onClick={() => setCurrentStep(step.id)}
                  className={cn(
                    "w-3 h-3 rounded-full transition-all",
                    currentStep === step.id
                      ? "bg-[var(--unicare-orange)] scale-125"
                      : currentStep > step.id
                        ? "bg-[var(--unicare-navy)]"
                        : "bg-gray-300"
                  )}
                  aria-label={`Step ${step.id}: ${step.label}`}
                />
              ))}
            </div>

            {currentStep < 3 ? (
              <Button
                size="lg"
                onClick={handleNext}
                className={cn(
                  "px-6 py-6 rounded-xl transition-all",
                  "bg-[var(--unicare-orange)] hover:bg-[var(--unicare-orange-light)] text-white",
                  "shadow-lg hover:shadow-xl hover:-translate-y-0.5"
                )}
              >
                다음
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            ) : (
              <div /> 
            )}
          </div>
        )}

        {/* Step 3 Submit Button */}
        {currentStep === 3 && (
          <div className="mt-8 space-y-4">
            <Button
              onClick={handleStep3Submit}
              className="w-full bg-[var(--unicare-orange)] hover:bg-orange-600 text-white py-8 rounded-2xl text-xl font-extrabold shadow-lg transition-all animate-bounce"
            >
              입력 완료 및 상담 신청하기
            </Button>
            <p className="text-center text-sm text-gray-400">버튼을 누르면 상담사에게 데이터가 실시간으로 전송됩니다.</p>
          </div>
        )}
      </div>
    </div>
  )
}
