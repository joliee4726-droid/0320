"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Lock, AlertCircle } from "lucide-react"
import { COUNSELORS, validateCounselorLogin } from "@/lib/counselor-auth"
import { cn } from "@/lib/utils"

export default function CounselorLoginPage() {
  const router = useRouter()
  const [selectedCounselor, setSelectedCounselor] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Check master password first
    if (password === "unicare-master") {
      // Store master session
      localStorage.setItem(
        "counselorSession",
        JSON.stringify({
          counselorName: "Master Admin",
          isMasterMode: true,
          loginTime: new Date().toISOString(),
        })
      )
      router.push("/dashboard")
      return
    }

    // Regular counselor login
    if (!selectedCounselor || !password) {
      setError("상담사 이름과 비밀번호를 입력해주세요")
      setIsLoading(false)
      return
    }

    const { valid } = validateCounselorLogin(selectedCounselor, password)

    if (!valid) {
      setError("비밀번호가 일치하지 않습니다")
      setIsLoading(false)
      return
    }

    // Store session
    localStorage.setItem(
      "counselorSession",
      JSON.stringify({
        counselorName: selectedCounselor,
        isMasterMode: false,
        loginTime: new Date().toISOString(),
      })
    )

    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--unicare-navy)] to-[var(--unicare-navy-light)] flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-0 shadow-2xl">
        <CardHeader className="bg-gradient-to-r from-[var(--unicare-navy)] to-[var(--unicare-navy-light)] rounded-t-xl text-white">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-3 bg-white/10 rounded-lg">
              <Lock className="w-6 h-6" />
            </div>
            <div>
              <CardTitle className="text-2xl">상담사 로그인</CardTitle>
              <CardDescription className="text-white/80">
                UNICARE 관리 시스템
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-8 space-y-6">
          <form onSubmit={handleLogin} className="space-y-6">
            {/* Master Mode Info */}
            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-sm text-amber-900">
              <p className="font-semibold mb-1">마스터 비밀번호 입력 시</p>
              <p>모든 상담사의 데이터를 통합 조회할 수 있습니다</p>
            </div>

            {/* Counselor Selection */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-[var(--unicare-navy)]">
                상담사 선택
              </label>
              <Select value={selectedCounselor} onValueChange={setSelectedCounselor}>
                <SelectTrigger className="h-11 rounded-xl border-2 focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]">
                  <SelectValue placeholder="상담사를 선택해주세요" />
                </SelectTrigger>
                <SelectContent>
                  {COUNSELORS.map((counselor) => (
                    <SelectItem key={counselor} value={counselor}>
                      {counselor}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-[var(--unicare-navy)]">
                비밀번호
              </label>
              <Input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value)
                  setError("")
                }}
                placeholder="비밀번호 입력"
                className="h-11 rounded-xl border-2 focus:border-[var(--unicare-orange)] focus:ring-[var(--unicare-orange)]"
              />
              <p className="text-xs text-gray-500 mt-1">
                일반 상담사: unicare2024 | 마스터: unicare-master
              </p>
            </div>

            {/* Error Alert */}
            {error && (
              <Alert variant="destructive" className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-800 font-medium">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            {/* Login Button */}
            <Button
              type="submit"
              disabled={isLoading}
              className={cn(
                "w-full h-11 rounded-xl font-semibold text-white",
                "bg-[var(--unicare-orange)] hover:bg-[var(--unicare-orange-light)]",
                "disabled:opacity-50 disabled:cursor-not-allowed",
                "transition-all duration-200"
              )}
            >
              {isLoading ? "로그인 중..." : "로그인"}
            </Button>
          </form>

          {/* Info Box */}
          <div className="p-4 bg-[var(--unicare-navy)]/5 rounded-lg border border-[var(--unicare-navy)]/10">
            <p className="text-xs text-gray-600 leading-relaxed">
              로그인 후 자신의 상담 리스트만 조회 및 관리할 수 있습니다.
              <br />
              다른 상담사의 데이터는 화면에 표시되지 않습니다.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
