# Google Sheets 통합 설정 가이드

UNICARE 시스템이 학생 상담 데이터를 Google Sheets에 자동으로 저장하도록 설정하는 방법입니다.

## 1단계: Google Sheets 생성

1. [Google Sheets](https://sheets.google.com)에 접속
2. **새로운 스프레드시트**를 생성하거나 기존 시트 사용
3. 시트 이름을 `UNICARE 상담 기록` 등으로 지정
4. 첫 번째 행에 다음과 같이 헤더를 작성:
   ```
   제출일시 | 상담사 | 사용자유형 | 성명 | 학번 | 성별 | 연락처 | 주전공 | 학적상태 | 진로신호(전) | 상담노트 | 진로신호(후) | 만족도
   ```

## 2단계: Google Apps Script 배포

1. Google Sheets 상단 메뉴에서 **확장 프로그램** → **Apps Script** 클릭
2. 기본 코드를 모두 삭제하고 다음 코드 붙여넣기:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  // 데이터가 들어올 때마다 새로운 행에 추가
  sheet.appendRow([
    new Date(), 
    data.counselor, 
    data.userType, 
    data.name, 
    data.studentId, 
    data.gender,
    data.phone,
    data.major,
    data.academicStatus,
    data.signalBefore,
    data.counselingNote,
    data.signalAfter,
    data.satisfaction
  ]);
  
  return ContentService.createTextOutput("Success");
}
```

3. **저장** 버튼 클릭 (프로젝트 이름: 예 "UNICARE Google Sheets")
4. 상단 **배포** 버튼 클릭 → **새로 배포** 선택
5. 배포 설정:
   - 유형: **웹 앱**
   - 다음 사용자로 실행: **본인 계정**
   - 다음 권한으로 액세스: **본인**
6. **배포** 클릭
7. 팝업에서 **배포 URL** 복사 (예: `https://script.google.com/macros/d/[ID]/exec`)

## 3단계: UNICARE 앱에 URL 설정

### v0에서 배포한 경우 (Vercel)

1. Vercel 프로젝트 대시보드 접속
2. 상단 **Settings** → **Environment Variables**
3. **Add** 버튼 클릭
4. 다음 정보 입력:
   - **Name**: `NEXT_PUBLIC_GOOGLE_SHEETS_URL`
   - **Value**: 2단계에서 복사한 배포 URL 붙여넣기
5. **Save** 클릭
6. 앱이 자동으로 재배포됨

### 로컬 개발 환경에서 테스트하는 경우

1. 프로젝트 루트에 `.env.local` 파일 생성 또는 수정
2. 다음 내용 추가:
```
NEXT_PUBLIC_GOOGLE_SHEETS_URL=https://script.google.com/macros/d/[배포URL]/exec
```
3. 개발 서버 재시작 (`npm run dev`)

## 4단계: 데이터 흐름 확인

학생이 상담을 완료하면:

1. ✅ 학생이 **"저장 & 엑셀 다운로드"** 버튼 클릭
2. ✅ 자동으로 Google Sheets에 데이터 저장
3. ✅ 개인용 CSV 파일 다운로드
4. ✅ 대시보드에 실시간 표시

## 5단계: 데이터 확인

1. Google Sheets를 새로고침하면 새로운 행이 추가되어 있음
2. 상담사는 대시보드에서 **엑셀 다운로드**로 전체 데이터 조회 가능

## 문제 해결

### Google Sheets에 데이터가 저장되지 않음

1. **배포 URL 확인**
   - 환경변수에 정확한 URL이 저장되었는지 확인
   - URL 끝에 `/exec`가 포함되어 있는지 확인

2. **Google Apps Script 권한 확인**
   - 배포 시 "다음 권한으로 액세스: 본인" 설정 확인
   - Google 계정이 해당 Google Sheets에 접근 권한이 있는지 확인

3. **CORS 정책**
   - `mode: "no-cors"`로 설정되어 있으므로 크로스 오리진 이슈 없음

4. **브라우저 콘솔에서 에러 확인**
   - F12 개발자 도구 → Console에서 에러 메시지 확인

### 배포 URL 재발급

기존 배포를 새 버전으로 업데이트하려면:

1. Google Apps Script 에디터에서 코드 수정
2. **배포** → **배포 관리** 클릭
3. 기존 배포 항목의 연필 아이콘 클릭
4. 코드 수정 후 **배포** 클릭 (새 URL 생성 안 함)

## 보안 주의사항

- `NEXT_PUBLIC_` 접두사는 클라이언트에 노출되는 환경변수입니다
- Google Sheets URL은 공개되어도 안전합니다 (Google Apps Script의 배포 설정으로 보호)
- 실제 프로덕션 환경에서는 서버 사이드 API 호출 권장

## 추가 정보

- Google Apps Script 문서: https://developers.google.com/apps-script
- Sheets API 참고: https://developers.google.com/sheets/api
